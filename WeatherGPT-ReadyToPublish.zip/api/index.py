"""
Vercel Serverless Entrypoint for WeatherGPT FastAPI Backend
"""
import sys
import os

# Add backend directory to sys.path so app modules are resolvable
current_dir = os.path.dirname(os.path.abspath(__file__))
backend_dir = os.path.join(current_dir, "..", "backend")
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from app.main import app
