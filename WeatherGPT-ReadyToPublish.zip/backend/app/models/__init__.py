"""Models package for WeatherGPT."""
